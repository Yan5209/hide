#!/bin/sh
# CNSLicenseRestore.sh — 许可证备份恢复脚本
# 在 SpringBoard 启动前由 launchd RunAtLoad 执行
# 检测 .cns_license 是否存在，不存在则从 /var/mobile/Documents 恢复备份

BACKUP="/var/mobile/Documents/.cns_license_bak"

# 检测 JB_ROOT (扫描 .jbroot-*)
JBROOT_BASE="/var/mobile/Containers/Shared/AppGroup"
for dir in "$JBROOT_BASE"/.jbroot-*; do
    if [ -d "$dir" ]; then
        export JB_ROOT="$dir"
        break
    fi
done

if [ -z "$JB_ROOT" ]; then
    echo "CNSLicenseRestore: 无法检测 JB_ROOT, 退出"
    exit 0
fi

LICENSE="${JB_ROOT}/var/mobile/Library/Preferences/.cns_license"
LICENSE_DIR="${JB_ROOT}/var/mobile/Library/Preferences"

# 许可证存在 → 无需恢复
if [ -f "$LICENSE" ]; then
    exit 0
fi

# 许可证不存在, 检查备份
if [ ! -f "$BACKUP" ]; then
    echo "CNSLicenseRestore: 许可证和备份均不存在, 退出"
    exit 0
fi

# 从备份恢复
mkdir -p "$LICENSE_DIR"
cp "$BACKUP" "$LICENSE"
chmod 600 "$LICENSE"

# 如果恢复成功, 发送通知让 tweak 重新验证
if [ -f "$LICENSE" ]; then
    echo "CNSLicenseRestore: 已从备份恢复许可证"
fi

exit 0