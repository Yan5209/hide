#!/bin/sh
# CNSVibCache.sh — 读取 rootfs 振动 plist 并管道传给解析 daemon
# 由 LaunchDaemon 在开机时调用 (launchd 可正确解析 /usr/libexec/ 路径)
# V26.11-18: Tweak 改用 raw syscall 直读, 此脚本仅作 LaunchDaemon 备份

# V27.8: 自动检测 JB_ROOT
JBROOT_BASE="/var/mobile/Containers/Shared/AppGroup"
for dir in "$JBROOT_BASE"/.jbroot-*; do
    if [ -d "$dir" ]; then
        export JB_ROOT="$dir"
        break
    fi
done

if [ -z "$JB_ROOT" ]; then
    echo "CNSVibCache: 无法检测 JB_ROOT, 退出"
    exit 0
fi

VIB_PLIST="/rootfs/var/mobile/Media/Vibrations/UserGeneratedVibrationPatterns.plist"
DAEMON="${JB_ROOT}/usr/libexec/CNSVibrationCacheDaemon"

if [ ! -x "$DAEMON" ]; then
    echo "CNSVibCache: daemon 不存在于 $DAEMON, 退出"
    exit 0
fi

if [ -f "$VIB_PLIST" ]; then
    cat "$VIB_PLIST" | "$DAEMON"
fi
