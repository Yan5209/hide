from PIL import Image, ImageDraw, ImageFilter, ImageChops
import math
import os

SIZE = 1024
CORNER_RADIUS = int(SIZE * 0.223)  # iOS-style squircle corner radius


def create_rounded_mask(size, radius):
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    return mask


def draw_gradient_background(img):
    """Light blue gradient: pale sky blue top -> soft ocean blue bottom."""
    pixels = img.load()
    top_r, top_g, top_b = 120, 210, 255    # #78D2FF pale sky blue
    bot_r, bot_g, bot_b = 70, 160, 225     # #46A0E1 soft ocean blue
    for y in range(img.height):
        t = y / (img.height - 1)
        r = int(top_r + (bot_r - top_r) * t)
        g = int(top_g + (bot_g - top_g) * t)
        b = int(top_b + (bot_b - top_b) * t)
        for x in range(img.width):
            pixels[x, y] = (r, g, b, 255)


def add_glass_effect(img):
    """Add frosted glass: top gloss highlight + diagonal light streak + bottom inner shadow."""
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    # Top glossy highlight — semi-transparent white fading down
    gloss_h = int(SIZE * 0.45)
    for y in range(gloss_h):
        t = y / gloss_h
        alpha = int(70 * (1 - t) ** 1.5)
        draw.line([(0, y), (SIZE, y)], fill=(255, 255, 255, alpha))

    # Diagonal specular light streak (top-left direction)
    streak = Image.new("RGBA", img.size, (0, 0, 0, 0))
    streak_draw = ImageDraw.Draw(streak)
    cx, cy = SIZE * 0.3, SIZE * 0.25
    streak_len = SIZE * 0.6
    angle = -math.radians(35)
    for i in range(int(streak_len)):
        offset = i - streak_len / 2
        px = cx + math.cos(angle) * offset
        py = cy + math.sin(angle) * offset
        thickness = int(SIZE * 0.08 * (1 - abs(offset) / (streak_len / 2)))
        if thickness > 0:
            perp_angle = angle + math.pi / 2
            x1 = px - math.cos(perp_angle) * thickness
            y1 = py - math.sin(perp_angle) * thickness
            x2 = px + math.cos(perp_angle) * thickness
            y2 = py + math.sin(perp_angle) * thickness
            fade = 1 - abs(offset) / (streak_len / 2)
            streak_draw.line([(x1, y1), (x2, y2)], fill=(255, 255, 255, int(25 * fade)))
    streak = streak.filter(ImageFilter.GaussianBlur(radius=12))
    overlay = Image.alpha_composite(overlay, streak)

    # Bottom inner shadow for depth
    shadow_h = int(SIZE * 0.15)
    for y in range(shadow_h):
        t = y / shadow_h
        alpha = int(40 * t)
        yy = SIZE - shadow_h + y
        draw.line([(0, yy), (SIZE, yy)], fill=(0, 20, 60, alpha))

    img.paste(overlay, (0, 0), overlay)


def draw_v_letter(img):
    """Draw a geometric red-orange 'V' with a split gap, soft shadow, and glass tint."""
    # V parameters
    v_top_y = int(SIZE * 0.25)
    v_bot_y = int(SIZE * 0.72)
    v_half_w = int(SIZE * 0.24)
    bar_w = int(SIZE * 0.085)
    gap_w = int(SIZE * 0.025)
    cx = SIZE // 2

    # Shadow layer (offset down-right)
    shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    offset = int(SIZE * 0.012)
    draw_v_shape(sd, cx + offset, v_top_y + offset, v_bot_y + offset,
                 v_half_w, bar_w, gap_w, (80, 15, 5, 90))
    shadow = shadow.filter(ImageFilter.GaussianBlur(radius=8))
    img.paste(shadow, (0, 0), shadow)

    # Main V — vibrant red-orange base
    v_layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    vd = ImageDraw.Draw(v_layer)
    draw_v_shape(vd, cx, v_top_y, v_bot_y, v_half_w, bar_w, gap_w, (255, 70, 20, 255))

    # Add vertical gradient to V: vivid orange-red top -> deep red-orange bottom
    v_gradient = Image.new("RGBA", img.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(v_gradient)
    v_mask = Image.new("L", img.size, 0)
    md = ImageDraw.Draw(v_mask)
    draw_v_shape(md, cx, v_top_y, v_bot_y, v_half_w, bar_w, gap_w, 255)
    for y in range(v_top_y, v_bot_y):
        t = (y - v_top_y) / (v_bot_y - v_top_y)
        r = int(255 - 20 * t)
        g = int(75 - 25 * t)
        b = int(20 - 5 * t)
        gd.line([(0, y), (SIZE, y)], fill=(r, g, b, 255))
    v_gradient.putalpha(v_mask)
    v_layer = Image.alpha_composite(v_layer, v_gradient)

    # Subtle gloss on V — faint warm highlight at top only
    # Build alpha map: per-line gloss alpha multiplied by V mask
    gloss_alpha = Image.new("L", img.size, 0)
    ga = ImageDraw.Draw(gloss_alpha)
    for y in range(v_top_y, v_bot_y):
        t = (y - v_top_y) / (v_bot_y - v_top_y)
        alpha = int(20 * (1 - t) ** 2)
        ga.line([(0, y), (SIZE, y)], fill=alpha)
    combined_alpha = ImageChops.multiply(gloss_alpha, v_mask)
    tint = Image.new("RGBA", img.size, (0, 0, 0, 0))
    td = ImageDraw.Draw(tint)
    td.rectangle([0, 0, SIZE, SIZE], fill=(255, 180, 100, 255))
    tint.putalpha(combined_alpha)
    v_layer = Image.alpha_composite(v_layer, tint)

    img.paste(v_layer, (0, 0), v_layer)


def draw_v_shape(draw, cx, top_y, bot_y, half_w, bar_w, gap_w, fill):
    """Draw the V as two angled parallelogram bars with a gap."""
    # Left bar: from top-left down to bottom-center-left
    left_top_outer = (cx - half_w, top_y)
    left_top_inner = (cx - half_w + bar_w, top_y)
    left_bot_inner = (cx - gap_w, bot_y)
    left_bot_outer = (cx - gap_w - bar_w * 0.4, bot_y)
    draw.polygon([left_top_outer, left_top_inner, left_bot_inner, left_bot_outer], fill=fill)

    # Right bar: from top-right down to bottom-center-right
    right_top_outer = (cx + half_w, top_y)
    right_top_inner = (cx + half_w - bar_w, top_y)
    right_bot_inner = (cx + gap_w, bot_y)
    right_bot_outer = (cx + gap_w + bar_w * 0.4, bot_y)
    draw.polygon([right_top_outer, right_top_inner, right_bot_inner, right_bot_outer], fill=fill)


def generate():
    # Create base image
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw_gradient_background(img)
    add_glass_effect(img)
    draw_v_letter(img)

    # Apply rounded corner mask
    mask = create_rounded_mask(SIZE, CORNER_RADIUS)
    rounded = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    rounded.paste(img, (0, 0), mask)

    # Save high-res version
    res_dir = os.path.dirname(os.path.abspath(__file__))

    # Generate all three sizes with high-quality downsampling
    sizes = {
        "icon.png": 30,
        "icon@2x.png": 60,
        "icon@3x.png": 90,
    }

    for filename, px in sizes.items():
        small = rounded.resize((px, px), Image.LANCZOS)
        path = os.path.join(res_dir, filename)
        small.save(path, "PNG")
        print(f"Saved {filename} ({px}x{px})")

    # Header icon — transparent background, V letter only (755x755)
    header = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw_v_letter(header)
    header = header.resize((755, 755), Image.LANCZOS)
    header.save(os.path.join(res_dir, "velvet-header-icon.png"), "PNG")
    print("Saved velvet-header-icon.png (755x755, transparent)")


if __name__ == "__main__":
    generate()
